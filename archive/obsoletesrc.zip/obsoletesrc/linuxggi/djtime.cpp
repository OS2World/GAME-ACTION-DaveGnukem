/*--------------------------------------------------------------------------*/
// djtime.cpp
//
// Copyright (C) David Joffe 1999
//
// License: GNU GPL
//
// General time functions
/*--------------------------------------------------------------------------*/
#include <string.h>
#include "../djtime.h"
#include <sys/time.h>
#include <unistd.h>
/*--------------------------------------------------------------------------*/
//
// Linux/unix version
//
/*--------------------------------------------------------------------------*/
// FIXME: gettimeofday doesn't seem to be returning the time of day, rather
// some sort of count since yonks back, so I subtract the initial time from
// each gettime to get a relative time.
struct timeval tInitial;

// Initialize the time system
void djTimeInit()
{
	struct timezone tz;
	gettimeofday( &tInitial, &tz );
}

// Shut down the time system
void djTimeDone()
{
}

// return time since djTime started in seconds
float djTimeGetTime()
{
	struct timeval t;
	struct timezone tz; // Meaningless (see "man gettimeofday")
	gettimeofday( &t, &tz );
	t.tv_sec -= tInitial.tv_sec;
	return (float)((double)t.tv_sec + (double)t.tv_usec/1000000.0);;
}

