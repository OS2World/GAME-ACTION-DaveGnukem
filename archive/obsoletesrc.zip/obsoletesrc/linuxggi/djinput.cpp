/*--------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------*/
#include <stdlib.h>
#include "../djinput.h"
#include <ggi/ggi.h>
#include <ggi/gii.h>
#include <sys/time.h> // For GII event poll
#include <string.h>
#include "../djgraph.h"
#include "../djlog.h"

int g_iKeys[DJKEY_MAX] = { 0 };
int g_iKeysLast[DJKEY_MAX] = { 0 };

// Translation tables: maps GII keyboard codes to DJKEY codes
SdjKeyMapping key_pairs[] =
{
   { DJKEY_F1,        GIIK_F1 },
   { DJKEY_F2,        GIIK_F2 },
   { DJKEY_F3,        GIIK_F3 },
   { DJKEY_F4,        GIIK_F4 },
   { DJKEY_F5,        GIIK_F5 },
   { DJKEY_F6,        GIIK_F6 },
   { DJKEY_F7,        GIIK_F7 },
   { DJKEY_F8,        GIIK_F8 },
   { DJKEY_F9,        GIIK_F9 },
   { DJKEY_F10,       GIIK_F10 },
   { DJKEY_F11,       GIIK_F11 },
   { DJKEY_F12,       GIIK_F12 },
   { DJKEY_GREYPLUS,  GIIK_PPlus },
   { DJKEY_GREYMINUS, GIIK_PMinus },
   { DJKEY_SPACE,     GIIUC_Space },
   { DJKEY_ENTER,     GIIK_Enter },
   { DJKEY_ESC,       GIIUC_Escape },
   { DJKEY_UP,        GIIK_Up },
   { DJKEY_DOWN,      GIIK_Down },
   { DJKEY_LEFT,      GIIK_Left },
   { DJKEY_RIGHT,     GIIK_Right },
   { DJKEY_HOME,      GIIK_Home },
   { DJKEY_END,       GIIK_End },
   { DJKEY_PGUP,      GIIK_PageUp },
   { DJKEY_PGDN,      GIIK_PageDown },
   { -1, 0 }
};
SdjKeyMapping key_pairs2[] =
{
   { DJKEY_ALT,       GIIK_AltR },
   { DJKEY_ALT,       GIIK_AltL },
   { DJKEY_CTRL,      GIIK_CtrlR },
   { DJKEY_CTRL,      GIIK_CtrlL },
   { DJKEY_a,         GIIUC_a },
   { DJKEY_A,         GIIUC_A },
   { DJKEY_b,         GIIUC_b },
   { DJKEY_B,         GIIUC_B },
   { DJKEY_c,         GIIUC_c },
   { DJKEY_C,         GIIUC_C },
   { DJKEY_d,         GIIUC_d },
   { DJKEY_D,         GIIUC_D },
   { DJKEY_e,         GIIUC_e },
   { DJKEY_E,         GIIUC_E },
   { DJKEY_f,         GIIUC_f },
   { DJKEY_F,         GIIUC_F },
   { DJKEY_g,         GIIUC_g },
   { DJKEY_G,         GIIUC_G },
   { DJKEY_h,         GIIUC_h },
   { DJKEY_H,         GIIUC_H },
   { DJKEY_i,         GIIUC_i },
   { DJKEY_I,         GIIUC_I },
   { DJKEY_j,         GIIUC_j },
   { DJKEY_J,         GIIUC_J },
   { DJKEY_k,         GIIUC_k },
   { DJKEY_K,         GIIUC_K },
   { DJKEY_l,         GIIUC_l },
   { DJKEY_L,         GIIUC_L },
   { DJKEY_m,         GIIUC_m },
   { DJKEY_M,         GIIUC_M },
   { DJKEY_n,         GIIUC_n },
   { DJKEY_N,         GIIUC_N },
   { DJKEY_o,         GIIUC_o },
   { DJKEY_O,         GIIUC_O },
   { DJKEY_p,         GIIUC_p },
   { DJKEY_P,         GIIUC_P },
   { DJKEY_q,         GIIUC_q },
   { DJKEY_Q,         GIIUC_Q },
   { DJKEY_r,         GIIUC_r },
   { DJKEY_R,         GIIUC_R },
   { DJKEY_s,         GIIUC_s },
   { DJKEY_S,         GIIUC_S },
   { DJKEY_t,         GIIUC_t },
   { DJKEY_T,         GIIUC_T },
   { DJKEY_u,         GIIUC_u },
   { DJKEY_U,         GIIUC_U },
   { DJKEY_v,         GIIUC_v },
   { DJKEY_V,         GIIUC_V },
   { DJKEY_w,         GIIUC_w },
   { DJKEY_W,         GIIUC_W },
   { DJKEY_x,         GIIUC_x },
   { DJKEY_X,         GIIUC_X },
   { DJKEY_y,         GIIUC_y },
   { DJKEY_Y,         GIIUC_Y },
   { DJKEY_z,         GIIUC_z },
   { DJKEY_Z,         GIIUC_Z },
   { DJKEY_0,         GIIUC_0 },
   { DJKEY_1,         GIIUC_1 },
   { DJKEY_2,         GIIUC_2 },
   { DJKEY_3,         GIIUC_3 },
   { DJKEY_4,         GIIUC_4 },
   { DJKEY_5,         GIIUC_5 },
   { DJKEY_6,         GIIUC_6 },
   { DJKEY_7,         GIIUC_7 },
   { DJKEY_8,         GIIUC_8 },
   { DJKEY_9,         GIIUC_9 },
   { -1, 0 }
};
/*--------------------------------------------------------------------------*/
gii_input_t   inpvis;
djVisual *g_pVisInput = NULL;
int           g_iFlags;
int           g_iEvMask;

int           mouse_x;
int           mouse_y;
int           mouse_b;
/*--------------------------------------------------------------------------*/
void djiPoll()
{
	// Remember the key state from last time round
	memcpy( g_iKeysLast, g_iKeys, sizeof(g_iKeys) );
	int    evmask;
	int    i;
	
	if (!g_pVisInput) return;

	evmask = g_iEvMask;
	
	// FIXME: This is temporary, should be moved.

	struct timeval t={0,0};
	if (0 != ggiEventPoll(g_pVisInput->vis, (gii_event_mask)evmask, &t/*ptime*/))
	{
		ggi_event ev;
		ggiEventRead(g_pVisInput->vis, &ev, (gii_event_mask)evmask );
		
		if (g_iFlags & INPUT_MOUSE)
		{
			// mouse move
			if (ev.any.type == evPtrAbsolute)
			{
				mouse_x = ev.pmove.x;
				mouse_y = ev.pmove.y;
			}
			// mouse button press
			else if (ev.any.type == evPtrButtonPress)
			{
				if (ev.pbutton.button == 1)       mouse_b |= 1;
				else if  (ev.pbutton.button == 2) mouse_b |= 2;
				else if  (ev.pbutton.button == 3) mouse_b |= 4;		  
			}
			// mouse button release
			else if (ev.any.type == evPtrButtonRelease)
			{
				if (ev.pbutton.button == 1)       mouse_b &= ~1;
				else if  (ev.pbutton.button == 2) mouse_b &= ~2;
				else if  (ev.pbutton.button == 3) mouse_b &= ~4;		  
			}
		}
		
		// Key Down
		if (ev.any.type == evKeyPress)
		{
			for ( i=0; key_pairs2[i].m_iScanCode != -1; i++ )
			{
				if (ev.key.label == key_pairs2[i].m_iPlatformCode)
					g_iKeys[key_pairs2[i].m_iScanCode] = 1;
			}
			for ( i=0; key_pairs[i].m_iScanCode != -1; i++ )
			{
				if (ev.key.sym == key_pairs[i].m_iPlatformCode)
					g_iKeys[key_pairs[i].m_iScanCode] = 1;
			}
		}
		// Key Up
		else if (ev.any.type == evKeyRelease)
		{
			for ( i=0; key_pairs2[i].m_iScanCode != -1; i++ )
			{
				if (ev.key.label == key_pairs2[i].m_iPlatformCode)
					g_iKeys[key_pairs2[i].m_iScanCode] = 0;
			}
			for ( i=0; key_pairs[i].m_iScanCode != -1; i++ )
			{
				if (ev.key.sym == key_pairs[i].m_iPlatformCode)
					g_iKeys[key_pairs[i].m_iScanCode] = 0;
			}
		} // if
		
	} // if
}

bool djiInit( djVisual *pVis, int iFlags )
{
	g_iFlags = iFlags;
	
	g_pVisInput = pVis;
	
	// Initialize GII
	if (giiInit() != 0)
	{
		djMSG("InputInit(): ggiInit() failed.\n");
		return false;
	}
	
	// Open GII on stdin
	if (NULL == (inpvis = giiOpen( "stdin" )))
	{
		djMSG("InputInit(): Fubar giiOpen\n");
	}
	
	// Initialize mouse variables
	mouse_b = 0;  // button
	mouse_x = -1; // x
	mouse_y = -1; // y

	// Set up GGI event mask
	g_iEvMask = 0;
	if (g_iFlags & INPUT_KEYDOWN)   g_iEvMask |= emKeyPress;
	if (g_iFlags & INPUT_KEYUP)     g_iEvMask |= emKeyRelease;
	if (g_iFlags & INPUT_KEYREPEAT) g_iEvMask |= emKeyRepeat; // ????
	if (g_iFlags & INPUT_MOUSE)
		g_iEvMask |= emPtrButtonPress | emPtrButtonRelease | emPtrAbsolute;
	
	TRACE("InputInit(): giiSetEventMask()\n");
	giiSetEventMask( inpvis, (gii_event_mask)g_iEvMask );
	
	return true;
}

void djiDone()
{
//   giiExit();
}

void djiWaitForKeyUp(char cKey)
{
	// FIXME: CPU KILLER
	do
	{
		djiPoll();
	} while (g_iKeys[cKey]);
}

bool djiAnyKeyDown()
{
	int i,r=0;
	for (i = 0;i<128;i++)
	{
		r = r | g_iKeys[i];
	}
	return(r!=0);
}

bool djiKeyDown(int iScanCode)
{
	return g_iKeys[iScanCode]!=0;
}

bool djiKeyPressed(int iScanCode)
{
	return (g_iKeys[iScanCode]!=0 && g_iKeysLast[iScanCode]==0);
}

