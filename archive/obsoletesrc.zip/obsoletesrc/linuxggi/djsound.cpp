/*--------------------------------------------------------------------------*/
// djsound.cpp
//
// Copyright (C) David Joffe 1999
//
// License: GNU GPL
//
// Sound interface
/*--------------------------------------------------------------------------*/
#include "../djsound.h"
#include "../djstring.h"
/*--------------------------------------------------------------------------*/
bool bSoundEnabled = false;
bool bHaveMixer;
/*--------------------------------------------------------------------------*/
//
// Common
//
/*--------------------------------------------------------------------------*/
void djSoundEnable()
{
	bSoundEnabled = true;
}

void djSoundDisable()
{
	bSoundEnabled = false;
}

bool djSoundEnabled()
{
	return bSoundEnabled;
}

int djSoundInit()
{
	djSoundEnable();
	return 0;
}

void djSoundDone()
{
}

SOUND_HANDLE djSoundLoad( char *szFilename )
{
	return SOUNDHANDLE_INVALID;
}

bool djSoundPlay( SOUND_HANDLE i )
{
	return true;
}

