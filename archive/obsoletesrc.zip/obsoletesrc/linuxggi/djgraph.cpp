
#include "../djgraph.h"
#include <ggi/ggi.h>
#include <stdio.h>
#include <string.h>

unsigned int djgMapColor( djVisual *pVis, djColor color )
{
	unsigned int ret;
	ggi_color col;
	
	ret = 0;
	
	switch ( pVis->bpp )
	{
	case 16:
		// FIXME: assume 5-6-5?
		ret = ((color.r/8)<<11) | ((color.g/4)<<5) | (color.b/8);
		break;
//	case 24:
//	case 32:
//		ret = ((color.r/256)<<16) | ((color.g/256)<<8) | (color.b/256);
//		break;
	default:
		col.r = color.r * 0x101u;
		col.g = color.g * 0x101u;
		col.b = color.b * 0x101u;
		ret = ggiMapColor( pVis->vis, &col );
	}
	
	return ret;
}

int djgInit()
{
	ggiInit();
	return 0;
}

int djgDone()
{
	ggiExit();
	return 0;
}

djVisual * djgOpenVisual( const char * vistype, int w, int h, int bpp, bool bBackbuffer/*=true*/ )
{
	djVisual * pVis;
	
	if (NULL == (pVis = new djVisual))
		return NULL;

	if (vistype==NULL)
		pVis->m_bFullscreen = false;
	else
		pVis->m_bFullscreen = ((!strcmp(vistype,"fullscreen")) ? true : false );
	
	const char *szVisualType = vistype;
	// Supported visual types
	if (vistype!=NULL)
	{
		if (!strcmp( vistype, "fullscreen" )) szVisualType = "dga";
	}
	
	// Open ggi visual
	if (NULL == (pVis->vis = ggiOpen( szVisualType )))
	{
		delete pVis;
		return NULL;
	}
	
	if (bpp == 0) // Auto-select bit depth
	{
		// Try 8-bit, then 16-bit, then 24-bit, then 32-bit
		pVis->bpp = 8;
		if (0 != ggiSetSimpleMode( pVis->vis, w, h, GGI_AUTO, GT_8BIT ))
		{
			pVis->bpp = 16;
			if (0 != ggiSetSimpleMode( pVis->vis, w, h, GGI_AUTO, GT_16BIT ))
			{
				pVis->bpp = 24;
				if (0 != ggiSetSimpleMode( pVis->vis, w, h, GGI_AUTO, GT_24BIT ))
				{
					pVis->bpp = 32;
					if (0 != ggiSetSimpleMode( pVis->vis, w, h, GGI_AUTO, GT_32BIT ))
						pVis->bpp = 0;
				}
			}
		}
	}
	else // specific bpp requested
	{
		pVis->bpp = bpp;
		if (0 != ggiSetSimpleMode( pVis->vis, w, h, GGI_AUTO,
			(bpp ==  8 ? GT_8BIT :
			(bpp == 16 ? GT_16BIT :
			(bpp == 24 ? GT_24BIT : GT_32BIT))) ) )
		{
			pVis->bpp = 0;
		}
	}
	
	if (pVis->bpp == 0)
	{
		printf("djgOpenVisual() couldn't set mode\n");
		goto error;
	}
	
	pVis->width = w;
	pVis->height = h;

	switch (pVis->bpp)
	{
	case  8: pVis->pixwidth = 1; break;
	case 16: pVis->pixwidth = 2; break;
	case 24: pVis->pixwidth = 3; break;
	case 32: pVis->pixwidth = 4; break;
	}
	
	// Set ASYNC flag
	if (!bSynchronous)
		ggiAddFlags( pVis->vis, GGIFLAG_ASYNC );

	// Get pointer to buffer
	pVis->m_pBuffer = ggiDBGetBuffer( pVis->vis, 0 );
	if (pVis->m_pBuffer == NULL)
	{
		printf( "djgOpenVisual(): unable to get frontbuf DirectBuffer.\n" );
		// FIXME: Howz about some, like, exception handling, like, dude ...
		goto error;
	}
	// Check if buffer is in linear format
	if ( pVis->m_pBuffer->layout != blPixelLinearBuffer )
	{
		printf( "djgOpenVisual(): frontbuffer DirectBuffer non-linear.\n" );
		goto error;
	}
	// get stride (the actual allocated buffer width)
	pVis->stride = pVis->m_pBuffer->buffer.plb.stride;
	
	printf( "djgOpenVisual(): new visual: [%d,%d] stride:%d, bpp:%d, pixwidth:%d\n",
		pVis->width, pVis->height, pVis->stride, pVis->bpp, pVis->pixwidth );
	
	return pVis;
	
error:
	
	ggiClose( pVis->vis );
	delete pVis;
	
	return NULL;
}

void djgCloseVisual( djVisual * pVis )
{
	ggiClose( pVis->vis );
}

void djgLock( djVisual * pVis )
{
}

void djgUnlock( djVisual * pVis )
{
}

/*--------------------------------------------------------------------------*/
//
//
//
/*--------------------------------------------------------------------------*/
void djgFlush( djVisual * pVis )
{
	ggiFlush( pVis->vis );
}

void djgFlip( djVisual * pVisDest, djVisual * pVisSrc )
{
	if (pVisSrc==NULL) // <-- HACK
		return;
	if (pVisDest->stride == pVisSrc->stride)
	{
		memcpy(
			(char*)pVisDest->m_pBuffer->write,
			(char*)pVisSrc->m_pBuffer->read,
			MIN( pVisDest->height, pVisSrc->height ) * pVisSrc->stride);
	}
	else
	{
		int y, ymin, xmin;
		ymin = MIN( pVisDest->height, pVisSrc->height );
		xmin = MIN( pVisDest->width, pVisSrc->width );
		
		for ( y=0; y<ymin; y++ )
		{
			memcpy(
				(char*)pVisDest->m_pBuffer->write + y * pVisDest->stride,
				(char*)pVisSrc->m_pBuffer->read + y * pVisSrc->stride,
				xmin * pVisSrc->pixwidth );
		}
	}
	
	// Do we do a flush here? I suppose so ..
	ggiFlush( pVisDest->vis );
}

void djgClear( djVisual * pVis )
{
	//   ggiSetGCForeground( pVis->vis, 293483434 );
	// FIXME: Is this always black?
	ggiFillscreen( pVis->vis );
}

void djgPutPixel( djVisual * pVis, int x, int y, int r, int g, int b )
{
	ggi_color col;
	unsigned int pixel;
	col.r = r * 0x101;
	col.g = g * 0x101;
	col.b = b * 0x101;
	pixel = ggiMapColor( pVis->vis, &col );
	memcpy( (char*)pVis->m_pBuffer->write + y*pVis->stride + x*pVis->pixwidth, &pixel, pVis->pixwidth );
	//   ggiPutPixel( pVis->vis, x, y, ggiMapColor( pVis->vis, &col ) );
}

void djgPutPixel( djVisual * pVis, int x, int y, djColor color )
{
	ggiPutPixel( pVis->vis, x, y, djgMapColor( pVis, color ) );
}

void djgSetColor( djVisual *pVis, djColor clrFore, djColor clrBack )
{
	djgSetColorFore( pVis, clrFore );
	djgSetColorBack( pVis, clrBack );
}

void djgSetColorFore( djVisual * pVis, djColor color )
{
	ggiSetGCForeground( pVis->vis, djgMapColor( pVis, color ) );
}

void djgSetColorBack( djVisual * pVis, djColor color )
{
	ggiSetGCBackground( pVis->vis, djgMapColor( pVis, color ) );
}

void djgDrawRectangle( djVisual * pVis, int x, int y, int w, int h )
{
	// FIXME: TEST THESE BOUNDS CHECKING
//	if (x<0) x=0;
//	if (y<0) y=0;
//	if (x+w>=pVis->width+1) w = pVis->width - x;
//	if (y+h>=pVis->height+1) h = pVis->height - y;
	djgDrawHLine( pVis, x    , y    , w );
	djgDrawHLine( pVis, x    , y+h-1/*-1*/, w );
	djgDrawVLine( pVis, x    , y    , h );
	djgDrawVLine( pVis, x+w-1/*-1*/, y    , h );
}

void djgDrawBox( djVisual * pVis, int x, int y, int w, int h )
{
	ggiDrawBox( pVis->vis, x, y, w, h );
}

void djgDrawHLine( djVisual * pVis, int x, int y, int n )
{
	ggiDrawLine( pVis->vis, x, y, x + n - 1, y );
}

void djgDrawVLine( djVisual * pVis, int x, int y, int n )
{
	ggiDrawLine( pVis->vis, x, y, x, y + n - 1);
}

void djgDrawImage( djVisual *pVis, djImage *pImage, int x, int y, int w, int h )
{
	djgDrawImage( pVis, pImage, 0, 0, x, y, w, h );
}

void djgDrawImage( djVisual *pVis, djImage *pImage, int xS, int yS, int xD, int yD, int w, int h )
{
	if (pImage==NULL) return;
	// FIXME: We have endianness problems all over the place

	if (xS<0 || yS<0) return;

	// clipping
	if (xD>=pVis->width || yD>=pVis->height) return;
	if (xD+w>pVis->width)  { w = pVis->width-xD; }
	if (yD+h>pVis->height) { h = pVis->height-yD; }
	if (xD<0) { w=w+xD; if (w<=0) return; xD=0; }
	if (yD<0) { h=h+yD; if (h<=0) return; yD=0; }

	// If same pixel formats, just copy
	if (pVis->bpp==pImage->BPP())
	{
		for ( int i=0; i<h; i++ )
		{
			memcpy(
				(char*)pVis->m_pBuffer->write + (yD+i)*pVis->stride + xD*pVis->pixwidth,
				pImage->Data() + (yS+i)*pImage->Pitch()+xS*pVis->pixwidth,
				w * pVis->pixwidth );
		}
		return;
	}

	if (pVis->bpp==16)
	{
		// 32-bit, no transparency
		if (pImage->BPP()==32)
		{
			for ( int i=0; i<h; i++ )
			{
				int iOffsetSrc = (yS+i)*pImage->Pitch() + xS*4;
				int iOffsetDest = (yD+i)*pVis->stride + xD*2;
				unsigned int   *pSrc = (unsigned int*)((char*)pImage->Data() + iOffsetSrc);
				unsigned short *pDest = (unsigned short*)((char*)pVis->m_pBuffer->read + iOffsetDest);
				for ( int j=0; j<w; j++ )
				{
					*pDest = PIXEL32TO16(*pSrc);
					pSrc++;
					pDest++;
				}
			}
			return;
		}
		
	}

	// fixme; other combinations
	// fixme; indexed mode


}

void djgDrawImageAlpha( djVisual *pVis, djImage * pImage, int xS, int yS, int xD, int yD, int w, int h )
{
	if (pImage==NULL) return;
	// FIXME: We have endianness problems all over the place

	// clipping
	if (xD>=pVis->width || yD>=pVis->height) return;
	if (xD+w>pVis->width)  { w = pVis->width-xD; }
	if (yD+h>pVis->height) { h = pVis->height-yD; }
	if (xD<0) { w=w+xD; if (w<=0) return; xD=0; }
	if (yD<0) { h=h+yD; if (h<=0) return; yD=0; }
	
	// 32-bit, alpha map
	if (pVis->bpp==32)
	{
		if (pImage->BPP()==32)
		{
			for ( int i=0; i<h; i++ )
			{
				int iOffsetSrc = (yS+i)*pImage->Pitch() + xS*4;
				int iOffsetDest = (yD+i)*pVis->stride + xD*4;
				unsigned int *pSrc = (unsigned int*)((char*)pImage->Data() + iOffsetSrc);
				unsigned int *pDest = (unsigned int*)((char*)pVis->m_pBuffer->write + iOffsetDest);
				for ( int j=0; j<w; j++ )
				{
					unsigned int pixel = *pSrc;
					// If alpha value non-zero
					if (pixel & 0xFF000000)
					{
						*pDest = pixel;
					}
					pSrc++;
					pDest++;
				}
			}
			return;
		}
	}
	if (pVis->bpp==16)
	{
		if (pImage->BPP()==32)
		{
			for ( int i=0; i<h; i++ )
			{
				int iOffsetSrc = (yS+i)*pImage->Pitch() + xS*4;
				int iOffsetDest = (yD+i)*pVis->stride + xD*2;
				unsigned int   *pSrc = (unsigned int*)((char*)pImage->Data() + iOffsetSrc);
				unsigned short *pDest = (unsigned short*)((char*)pVis->m_pBuffer->read + iOffsetDest);
				for ( int j=0; j<w; j++ )
				{
					unsigned int pixel = *pSrc;
					// If alpha value non-zero
					if (pixel & 0xFF000000)
					{
						*pDest = PIXEL32TO16(pixel);
					}
					pSrc++;
					pDest++;
				}
			}
			return;
		}
	}
}

void djgDrawVisual( djVisual *pDest, djVisual *pSrc, int xD, int yD, int xS, int yS, int w, int h )
{
	char * dest;
	char * src;
	int i;

	// if pixel formats are the same, just memcpy the region
	// FIXME: TEST IF PIXELFORMATS ARE THE SAME, right nowjst asume
	dest = (char*)pDest->m_pBuffer->write + yD*pDest->stride + xD*pDest->pixwidth;
	src  = (char*)pSrc->m_pBuffer->read   + yS*pSrc->stride  + xS*pSrc->pixwidth;
	for ( i=0; i<h; i++ )
	{
		memcpy( dest, src, w*pSrc->pixwidth );
		dest += pDest->stride;
		src += pSrc->stride;
	}
}

