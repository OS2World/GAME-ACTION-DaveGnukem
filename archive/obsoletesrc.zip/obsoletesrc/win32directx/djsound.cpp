/*--------------------------------------------------------------------------*/
// djsound.cpp
//
// Copyright (C) David Joffe 1999
//
// License: GNU GPL
//
// Sound interface
/*--------------------------------------------------------------------------*/
#include "../djsound.h"
#include "../djstring.h"

bool bSoundEnabled = false;
bool bHaveMixer;
/*--------------------------------------------------------------------------*/
//
// Common
//
/*--------------------------------------------------------------------------*/
void djSoundEnable()
{
	bSoundEnabled = true;
}

void djSoundDisable()
{
	bSoundEnabled = false;
}

bool djSoundEnabled()
{
	return bSoundEnabled;
}
/*--------------------------------------------------------------------------*/

#include <dsound.h>
#include "../djgraph.h" // For the hWnd

// Forward declarations
LPDIRECTSOUNDBUFFER CreateSoundBuffer(DWORD dwBuf, DWORD dwBufSize, DWORD dwFreq, DWORD dwBitsPerSample, 
									  DWORD dwBlkAlign, bool bStereo/*, BOOL bStaticBuf*/);
BOOL ReadData(LPDIRECTSOUNDBUFFER lpDSB, FILE* pFile, DWORD dwSize, DWORD dwPos);

vector<SdjSound> g_aSounds;

LPDIRECTSOUND g_pDS = NULL; // DirectSound object
/*--------------------------------------------------------------------------*/
int djSoundInit()
{
	HRESULT hr;
	
	// Create DirectSound object
	hr = DirectSoundCreate(NULL, &g_pDS, NULL);
	if (FAILED(hr))
	{
		djSoundDisable();
		return -1;
	}

	// Set the DirectSound cooperative level
	g_pDS->SetCooperativeLevel(g_hWnd, DSSCL_NORMAL);


	
	djSoundEnable();
	return 0;
}

void djSoundDone()
{
}

SOUND_HANDLE djSoundLoad( char *szFilename )
{
	if (szFilename==NULL)  return SOUNDHANDLE_INVALID; // NULL string
	if (szFilename[0]==0)  return SOUNDHANDLE_INVALID; // empty string
	if (!g_pDS)            return SOUNDHANDLE_INVALID; // Sound not initialized
	if (!djSoundEnabled()) return SOUNDHANDLE_INVALID; // Sound disabled
	
	SdjSound Sound;

	
	
	

	// Open the file
	FILE *fin;
	if (NULL == (fin = fopen(szFilename, "rb")))
		return SOUNDHANDLE_INVALID;

	// Read wave header
	WaveHeader wavHdr;
	if (fread(&wavHdr, sizeof(wavHdr), 1, fin) != 1) 
	{
		fclose(fin);
		return SOUNDHANDLE_INVALID;
	}

	// Figure out the size of the data region
	unsigned int uSize = wavHdr.dwDSize;
	
	// Is this a stereo or mono file?
	bool bStereo = wavHdr.wChnls > 1 ? true : false;
	
/*	LOG(TRACELOG, "Loading %s:[%s] Sampling rate: %d  BPS: %d",
		pszFileName,
		(bStereo ? "Stereo" : "Mono"),
		(int)wavHdr.dwSRate,
		(int)wavHdr.BitsPerSample);*/
	
	// Create the sound buffer for the wave file
	DWORD dwBuf = 0;
	Sound.m_pSoundBuffer = CreateSoundBuffer(dwBuf, uSize, wavHdr.dwSRate, wavHdr.BitsPerSample, wavHdr.wBlkAlign, bStereo);
	if (Sound.m_pSoundBuffer == NULL)
	{
		//LOG(ERRLOG, "CreateBufferFromWaveFile(%s): failed to create sound buffer", pszFileName);
		fclose(fin);
		return SOUNDHANDLE_INVALID;
	}
	
	// Read the data for the wave file into the sound buffer
	if (!ReadData(Sound.m_pSoundBuffer, fin, uSize, sizeof(wavHdr))) 
	{
		fclose(fin);
		return SOUNDHANDLE_INVALID;
	}
	
	// Close out the wave file
	fclose(fin);

	// fixme; test if loaded already
	static int iHandle=1;
	iHandle++;
	Sound.m_iHandle = iHandle;
	Sound.m_szFilename = djStrDeepCopy( szFilename );
	g_aSounds.push_back(Sound);
	
	// Yahoo!
	return Sound.m_iHandle;
	// FIXME: FOR NOW ASusme its a wav file
}

LPDIRECTSOUNDBUFFER CreateSoundBuffer(DWORD dwBuf, DWORD dwBufSize, DWORD dwFreq, DWORD dwBitsPerSample, 
									  DWORD dwBlkAlign, bool bStereo)
{
	LPDIRECTSOUNDBUFFER pSoundBuffer;
	PCMWAVEFORMAT pcmwf;
	DSBUFFERDESC dsbdesc;

	if (!djSoundEnabled()) return NULL;


	// Set up wave format structure.
	memset( &pcmwf, 0, sizeof(PCMWAVEFORMAT) );
	pcmwf.wf.wFormatTag         = WAVE_FORMAT_PCM;
	pcmwf.wf.nChannels          = bStereo ? 2 : 1;
	pcmwf.wf.nSamplesPerSec     = dwFreq;
	pcmwf.wf.nBlockAlign        = (WORD)dwBlkAlign;
	pcmwf.wf.nAvgBytesPerSec    = pcmwf.wf.nSamplesPerSec * pcmwf.wf.nBlockAlign;
	pcmwf.wBitsPerSample        = (WORD)dwBitsPerSample;
	
	// Set up DSBUFFERDESC structure.
	memset(&dsbdesc, 0, sizeof(DSBUFFERDESC));  // Zero it out. 
	dsbdesc.dwSize              = sizeof(DSBUFFERDESC);
	dsbdesc.dwFlags             = /*DSBCAPS_CTRL3D |*/ DSBCAPS_CTRLPAN;               // Needed creation flag for Direct 3D Sound
	dsbdesc.dwBufferBytes       = dwBufSize; 
	dsbdesc.lpwfxFormat         = (LPWAVEFORMATEX)&pcmwf;
	
	g_pDS->CreateSoundBuffer(&dsbdesc, &pSoundBuffer, NULL);
	
	if (pSoundBuffer == NULL)
	{
//		LOG(ERRLOG, "CreateSoundBuffer(): Unable to create sound buffer");
		return NULL;
	}
	
	// Yahoo!
	return pSoundBuffer;
}

//----------------------------------------------------------------------
// 
// Function     : ReadData()
//
// Purpose      : Reads in data from a wave file
//
//----------------------------------------------------------------------

BOOL ReadData(LPDIRECTSOUNDBUFFER lpDSB, FILE* pFile, DWORD dwSize, DWORD dwPos) 
{
	if (!djSoundEnabled()) return TRUE;

	// Seek to correct position in file (if necessary)
	if (dwPos != 0xffffffff) 
	{
		if (fseek(pFile, dwPos, SEEK_SET) != 0) 
		{
			return FALSE;
		}
	}
	
	// Lock data in buffer for writing
	LPVOID pData1;
	DWORD  dwData1Size;
	LPVOID pData2;
	DWORD  dwData2Size;
	HRESULT rval;
	
	rval = lpDSB->Lock(0, dwSize, &pData1, &dwData1Size, &pData2, &dwData2Size, DSBLOCK_FROMWRITECURSOR);
	if (rval != DS_OK)
	{
		return FALSE;
	}
	
	// Read in first chunk of data
	if (dwData1Size > 0) 
	{
		if (fread(pData1, dwData1Size, 1, pFile) != 1)
		{
			char holder[256];
			wsprintf(holder,"Data1 : %d, dwdata: %d, pFile: %d",pData1,dwData1Size,pFile);
			OutputDebugString(holder);
			return FALSE;
		}
	}
	
	// read in second chunk if necessary
	if (dwData2Size > 0) 
	{
		if (fread(pData2, dwData2Size, 1, pFile) != 1) 
		{
			return FALSE;
		}
	}
	
	// Unlock data in buffer
	rval = lpDSB->Unlock(pData1, dwData1Size, pData2, dwData2Size);
	if (rval != DS_OK)
	{
		return FALSE;
	}
	
	// Yahoo!
	return TRUE;
}

bool djSoundPlay( SOUND_HANDLE iHandle )
{
	if (!djSoundEnabled()) return false;
	if (iHandle==SOUNDHANDLE_INVALID) return false;
	for ( int i=0; i<g_aSounds.size(); i++ )
	{
		SdjSound Sound = g_aSounds[i];
		if (Sound.m_iHandle==iHandle)
		{
			DWORD dwStatus;
			Sound.m_pSoundBuffer->GetStatus(&dwStatus);
			
//			if ((dwStatus & DSBSTATUS_PLAYING) != DSBSTATUS_PLAYING)
			{
				// Play the sound
				Sound.m_pSoundBuffer->Play(0, 0, 0);
//				if (Failed(hr))
//				{
//					LOG(ERRLOG, "PlaySoundDS() Failed: %s", ErrorToStringSound(hr));
//				}
			}
		}
	}
	
	return true;
}

