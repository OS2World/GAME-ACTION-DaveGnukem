
#include "../djgraph.h"
#include <windows.h>

extern int main( int argc, char ** argv );

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
                             LPSTR lpCmdLine, int nCmdShow)
{
#ifndef USESDL
	// Extra initialization needed for Windows
	djgInitWin32( (int)hInstance );
#endif

	// FIXME: The intel compiler thinks that you cannot do this .. ???
	// Run the standard "main" function
	return main(__argc, __argv);
}


