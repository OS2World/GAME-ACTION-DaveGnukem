/*--------------------------------------------------------------------------*
// djgraph.cpp : Defines the entry point for the DLL application.
// It's not worth even trying to use the same .cpp file for both GGI
// and DirectDraw versions of this. So I'm using seperate files for
// the implementation.
/*--------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------*/

// The reason I can't use precompiled headers through stdafx.h seems
// to be some sort of stupid visual c++ compiler bug that makes:
//  #ifdef WIN32
//  #include "stdafx.h"
//  #endif
// not work.

#include "../djgraph.h"
#include <ddraw.h>
#include <string.h>
#include <stdio.h>
#include <windows.h>
/*--------------------------------------------------------------------------*/
// Private methods and attributes, used for DirectDraw platform only
int create_window( int iWidth, int iHeight, bool bFullScreen );
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

// This DFILSDJFEWT&SDFETFges^FDTSF brain-damage is here because DirectInput
// is completely brain damaged. So I'm not using it. Which means passing messages
// about all over the fucking place, so much for my intended modularity. What a screwup.
extern bool InputWndProc(HWND, UINT, WPARAM, LPARAM);

// Should this be exported?
LPDIRECTDRAW g_pDD;
LPDIRECTDRAWCLIPPER g_pClipper;

const char * g_szClassName = "djgWindowClass";
HWND      g_hWnd=NULL;
HINSTANCE g_hInstance=NULL;


// For primary surfaces, translations are needed for primitives
void TranslatePoint( int& x, int &y )
{
	POINT p;
	p.x = 0;
	p.y = 0;
	::ClientToScreen( g_hWnd, &p );
	x += p.x;
	y += p.y;
}




void djgInitWin32( int hInstance )
{
   g_hInstance = (HINSTANCE)hInstance;
}

/*==========================================================================*/
//
// Color management
//
/*==========================================================================*/

/*--------------------------------------------------------------------------*/
unsigned int djgMapColor( djVisual * pVis, djColor color )
{
	unsigned int ret = 0;
	
	switch ( pVis->bpp )
	{
	case 16:
		// FIXME: assume 5-6-5 = wrong
		ret = ((color.r/8)<<11) | ((color.g/4)<<5) | (color.b/8);
		break;
	case 24:
	case 32:
		ret = 0xFF000000 | (color.r<<16) | (color.g<<8) | color.b;
		break;
	}
	
	return ret;
}
/*--------------------------------------------------------------------------*/

/*==========================================================================*/
//
// Visual management
//
/*==========================================================================*/

/*--------------------------------------------------------------------------*/
int djgInit()
{
	HRESULT hr;
	
	g_hWnd = NULL;
	
	// FIXME: Enumerate
	hr = DirectDrawCreate( NULL, &g_pDD, NULL );
	if (FAILED(hr))
		return -1;
	return 0;
}

int djgDone()
{
	// Release DirectDraw
	if (g_pDD != NULL)
		g_pDD->Release();

	// Destroy window
	if (g_hWnd != NULL)
	{
		DestroyWindow(g_hWnd);
	}
	
	return 0;
}

djVisual * djgOpenVisual( const char * vistype, int w, int h, int bpp, bool bSynchronous/*=true*/ )
{
	djVisual * pVis;
	DDSURFACEDESC ddsd;
	HRESULT hr;
	memset( &ddsd, 0, sizeof(ddsd) );
	ddsd.dwSize = sizeof(ddsd);
	
	// Create a djVisual struct
	if (NULL == (pVis = new djVisual))
		return NULL;

	pVis->m_bFullscreen = false;
	pVis->m_bPrimary = false;
	
	// Create a default visual, just a plain non-resizing window
	if (NULL == vistype)
	{
		// Create a window
		if ( 0 != create_window( w, h, false ) )
			return NULL;
		
		// Set the directdraw cooperative level
		hr = g_pDD->SetCooperativeLevel( g_hWnd, DDSCL_NORMAL );
		// FIXME: SHould destroy the window here etc.
		if (FAILED(hr))
			return NULL;
		
		// Create the primary surface
		ddsd.dwFlags = DDSD_CAPS;
		ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE;
		hr = g_pDD->CreateSurface( &ddsd, &pVis->vis, NULL );
		if (FAILED(hr))
			return NULL;
		
		// Create and attach a clipper
		if (FAILED(hr = g_pDD->CreateClipper( 0, &g_pClipper, NULL ))) return NULL;
		if (FAILED(hr = g_pClipper->SetHWnd( 0, g_hWnd )))             return NULL;
		if (FAILED(hr = pVis->vis->SetClipper( g_pClipper )))          return NULL;

		pVis->m_bPrimary = true;
	}
	else if (0 == strcmp( vistype, "memory" ))
	{
		// Create a system memory surface
		ddsd.dwFlags = DDSD_CAPS | DDSD_WIDTH | DDSD_HEIGHT;
		ddsd.dwWidth = w;
		ddsd.dwHeight = h;
		ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_SYSTEMMEMORY;
		hr = g_pDD->CreateSurface( &ddsd, &pVis->vis, NULL );
		if (FAILED(hr))
			return NULL;
	}
	// or "dga"
	else if (0 == strcmp( vistype, "fullscreen" ))
	{
		// Create a window
		if ( 0 != create_window( w, h, true ) )
			return NULL;
		
		// Set the directdraw cooperative level
		hr = g_pDD->SetCooperativeLevel( g_hWnd, DDSCL_EXCLUSIVE|DDSCL_FULLSCREEN|DDSCL_NOWINDOWCHANGES );
		// FIXME: SHould destroy the window here etc.
		if (FAILED(hr)) return NULL;

		hr = g_pDD->SetDisplayMode( w, h, 32 );
		if (FAILED(hr)) ::MessageBeep(~0); // FIXME
		
		// Create the primary surface
		ddsd.dwFlags = DDSD_CAPS;
		ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE;
		hr = g_pDD->CreateSurface( &ddsd, &pVis->vis, NULL );
		if (FAILED(hr))
			return NULL;

		pVis->m_bFullscreen = true;
	}
	
	// Obtain info from the the created surface
	hr = pVis->vis->GetSurfaceDesc( &ddsd );
	if (FAILED(hr))
		return NULL;
	
	pVis->width = ddsd.dwWidth;
	pVis->height = ddsd.dwHeight;
	pVis->stride = ddsd.lPitch;
	pVis->bpp = ddsd.ddpfPixelFormat.dwRGBBitCount;
	switch (pVis->bpp)
	{
	case  8: pVis->pixwidth = 1; break;
	case 16: pVis->pixwidth = 2; break;
	case 24: pVis->pixwidth = 3; break; // FIXME: 4?
	case 32: pVis->pixwidth = 4; break;
	}
	
	// Lock the surface so that we can get a pointer to the memory
	djgLock( pVis );
	djgUnlock( pVis );
	
	//	char szBuf[1024];
	//	sprintf( szBuf, "%d %d %d %x %d %d", pVis->width, pVis->height, pVis->stride, pVis->m_pBuffer, pVis->bpp, pVis->pixwidth );
	//	MessageBox( g_hWnd, szBuf, "DFDFJDFK", MB_OK );
	
	return pVis;
}

void djgCloseVisual( djVisual * pVis )
{
	HRESULT hr;
	hr = pVis->vis->Release();

	// If this was a full-screen surface, restore the display mode
	if (pVis->m_bFullscreen)
	{
		hr = g_pDD->RestoreDisplayMode();
		if (FAILED(hr)) hr=hr; // FIXME
	}

}

// djgLock and djgUnlock are only relevant for DirectDraw, since we need
// to lock the surface each time we want a valid pointer to the memory
// associated with the surface
void djgLock( djVisual * pVis )
{
	static DDSURFACEDESC ddsd;
	static HRESULT       hr;
	memset( &ddsd, 0, sizeof(ddsd) );
	ddsd.dwSize = sizeof(ddsd);
	
	hr = pVis->vis->Lock( NULL, &ddsd, DDLOCK_WAIT | DDLOCK_SURFACEMEMORYPTR, NULL );
	pVis->m_pBuffer = (char*)ddsd.lpSurface;
}

void djgUnlock( djVisual * pVis )
{
	pVis->vis->Unlock( NULL );
}


/*==========================================================================*/
//
// 2D drawing functions
//
/*==========================================================================*/


void djgFlush( djVisual * pVis )
{
}

void djgFlip( djVisual * pVisDest, djVisual * pVisSrc )
{
	if (pVisSrc==NULL) // <-- HACK
		return;
	RECT rcSrc;
	SetRect( &rcSrc, 0, 0,
		MIN( pVisDest->width, pVisSrc->width ),
		MIN( pVisDest->height, pVisSrc->height ) );
	if (pVisDest->m_bFullscreen)
	{
		HRESULT hr;
		hr = pVisDest->vis->Blt( NULL, pVisSrc->vis, &rcSrc, DDBLT_WAIT, NULL );
		if (FAILED(hr))
			OutputDebugString( (LPCTSTR)"Royal fuckup in fullscreen\n" );
	}
	else
	{
		// FIXME: Does this stuff apply if a memory buffer "flip" ?
		RECT  rcDest;
		POINT p;
		p.x = 0;
		p.y = 0;
		::ClientToScreen( g_hWnd, &p );
		::GetClientRect( g_hWnd, &rcDest );
		OffsetRect( &rcDest, p.x, p.y );
		
		HRESULT hr;
		hr = pVisDest->vis->Blt( &rcDest, pVisSrc->vis, &rcSrc, DDBLT_WAIT, NULL );
		if (FAILED(hr))
			OutputDebugString( (LPCTSTR)"Royal fuckup\n" );
	}
}

void djgClear( djVisual * pVis )
{
	// If we're clearing a primary "window" surface, just clear the window
	if (pVis->m_bPrimary)
	{
		HDC hdc = GetDC( g_hWnd );
		if (hdc)
		{
			BitBlt( hdc, 0, 0, pVis->width, pVis->height, NULL, 0, 0, BLACKNESS );
			ReleaseDC( g_hWnd, hdc );
		}
	}
	else
	{
		djgLock( pVis );
		memset( pVis->m_pBuffer, 0, pVis->stride * pVis->height );
		djgUnlock( pVis );
	}
}

void djgPutPixel( djVisual * pVis, int x, int y, int r, int g, int b )
{
	if (pVis->m_bPrimary) TranslatePoint( x, y );
	// FIXME: For frontbuffers this is wrong. Yet we may still want
	// to do it the "wrong" way (ie think of that silly mosquito app
	// directdraw sample)
	djColor       col;
	unsigned int pixel;
	
	col = djColor( r, g, b );
	pixel = djgMapColor( pVis, col );
	
	djgLock( pVis );
	memcpy( pVis->m_pBuffer + y*pVis->stride + x*pVis->pixwidth, &pixel, pVis->pixwidth );
	djgUnlock( pVis );
}

void djgPutPixel( djVisual * pVis, int x, int y, djColor color )
{
	if (pVis->m_bPrimary) TranslatePoint( x, y );
	unsigned int pixel;
	
	pixel = djgMapColor( pVis, color );
	
	djgLock( pVis );
	memcpy( pVis->m_pBuffer + y*pVis->stride + x*pVis->pixwidth, &pixel, pVis->pixwidth );
	djgUnlock( pVis );
}

void djgSetColorFore( djVisual * pVis, djColor color )
{
	pVis->colorfore.r = color.r;
	pVis->colorfore.g = color.g;
	pVis->colorfore.b = color.b;
}

void djgSetColor( djVisual *pVis, djColor clrFore, djColor clrBack )
{
	djgSetColorFore( pVis, clrFore );
	djgSetColorBack( pVis, clrBack );
}

void djgSetColorBack( djVisual * pVis, djColor color )
{
	pVis->colorback.r = color.r;
	pVis->colorback.g = color.g;
	pVis->colorback.b = color.b;
}

void djgDrawRectangle( djVisual * pVis, int x, int y, int w, int h )
{
	// FIXME: TEST THESE BOUNDS CHECKING
//	if (x<0) x=0;
//	if (y<0) y=0;
//	if (x+w>=pVis->width+1) w = pVis->width - x;
//	if (y+h>=pVis->height+1) h = pVis->height - y;
	djgDrawHLine( pVis, x  , y  , w );
	djgDrawHLine( pVis, x  , y+h-1, w );
	djgDrawVLine( pVis, x  , y  , h );
	djgDrawVLine( pVis, x+w-1, y  , h );
}

void djgDrawBox( djVisual * pVis, int x, int y, int w, int h )
{
	if (pVis->m_bPrimary) TranslatePoint( x, y );
	unsigned int pixel = djgMapColor( pVis, pVis->colorfore );
	
	djgLock( pVis );
	char *pDest;
	for ( int i=0; i<h; i++ )
	{
		pDest = (char*)pVis->m_pBuffer + (y+i)*pVis->stride + x*pVis->pixwidth;
		for ( int j=0; j<w; j++ )
		{
			memcpy( (void*)pDest, &pixel, pVis->pixwidth );
			pDest += pVis->pixwidth;
		}
	}
	djgUnlock( pVis );
}

void djgDrawHLine( djVisual * pVis, int x, int y, int n )
{
	if (y<0 || y>=pVis->height) return;
	if (x<0) { n=n+x; if (n<=0) return; x=0; }
	if (x+n>pVis->width) { n=pVis->width-x; }
	if (n<=0) return;
	
	if (pVis->m_bPrimary) TranslatePoint( x, y );
	unsigned int pixel = djgMapColor( pVis, pVis->colorfore );
	
	djgLock( pVis );
	for ( int i=0; i<n; i++ )
		memcpy( pVis->m_pBuffer + y*pVis->stride + (x+i)*pVis->pixwidth, &pixel, pVis->pixwidth );
	djgUnlock( pVis );
}

void djgDrawVLine( djVisual * pVis, int x, int y, int n )
{
	if (x<0 || x>=pVis->width) return;
	if (y<0) { n=n+y; if (n<=0) return; y=0; }
	if (y+n>pVis->height) { n=pVis->height-y; }
	if (n<=0) return;
	
	if (pVis->m_bPrimary) TranslatePoint( x, y );
	unsigned int pixel = djgMapColor( pVis, pVis->colorfore );
	
	djgLock( pVis );
	for ( int i=0; i<n; i++ )
		memcpy( pVis->m_pBuffer + (y+i)*pVis->stride + x*pVis->pixwidth, &pixel, pVis->pixwidth );
	djgUnlock( pVis );
}

void djgDrawImage( djVisual *pVis, djImage *pImage, int x, int y, int w, int h )
{
	djgDrawImage( pVis, pImage, 0, 0, x, y, w, h );
}

void djgDrawImage( djVisual *pVis, djImage *pImage, int xS, int yS, int xD, int yD, int w, int h )
{
	if (pImage==NULL) return;
	// FIXME: We have endianness problems all over the place

	if (xS<0 || yS<0) return;

	// clipping
	if (xD>=pVis->width || yD>=pVis->height) return;
	if (xD+w>pVis->width)  { w = pVis->width-xD; }
	if (yD+h>pVis->height) { h = pVis->height-yD; }
	if (xD<0) { w=w+xD; if (w<=0) return; xD=0; }
	if (yD<0) { h=h+yD; if (h<=0) return; yD=0; }

	if (pVis->m_bPrimary) TranslatePoint( xD, yD );

	// If same pixel formats, just copy
	if (pVis->bpp==pImage->BPP())
	{
		djgLock(pVis);
		for ( int i=0; i<h; i++ )
		{
			memcpy(
				(char*)pVis->m_pBuffer + (yD+i)*pVis->stride + xD*pVis->pixwidth,
				pImage->Data() + (yS+i)*pImage->Pitch()+xS*pVis->pixwidth,
				w * pVis->pixwidth );
		}
		djgUnlock(pVis);
		return;
	}

	// 32-bit, no transparency
	if (pVis->bpp==32)
	{
		if (pImage->BPP()==16)
		{
		}
	}
	if (pVis->bpp==16)
	{
		// 32-bit, no transparency
		if (pImage->BPP()==32)
		{
			djgLock( pVis );
			for ( int i=0; i<h; i++ )
			{
				int iOffsetSrc = (yS+i)*pImage->Pitch() + xS*4;
				int iOffsetDest = (yD+i)*pVis->stride + xD*2;
				unsigned int   *pSrc = (unsigned int*)((char*)pImage->Data() + iOffsetSrc);
				unsigned short *pDest = (unsigned short*)((char*)pVis->m_pBuffer + iOffsetDest);
				for ( int j=0; j<w; j++ )
				{
					*pDest = PIXEL32TO16(*pSrc);
					pSrc++;
					pDest++;
				}
			}
			djgUnlock( pVis );
			return;
		}
	}
}

void djgDrawImageAlpha( djVisual *pVis, djImage *pImage, int xS, int yS, int xD, int yD, int w, int h )
{
	if (pImage==NULL) return;

	// clipping
	if (xD>=pVis->width || yD>=pVis->height) return;
	if (xD+w>pVis->width)  { w = pVis->width-xD; }
	if (yD+h>pVis->height) { h = pVis->height-yD; }
	if (xD<0) { w=w+xD; if (w<=0) return; xD=0; }
	if (yD<0) { h=h+yD; if (h<=0) return; yD=0; }

	if (pVis->m_bPrimary) TranslatePoint( xD, yD );
	
	// 32-bit, alpha map
	if (pVis->bpp==32)
	{
		if (pImage->BPP()==32)
		{
			djgLock( pVis );
			for ( int i=0; i<h; i++ )
			{
				int iOffsetSrc = (yS+i)*pImage->Pitch() + xS*4;
				int iOffsetDest = (yD+i)*pVis->stride + xD*4;
				unsigned int *pSrc = (unsigned int*)((char*)pImage->Data() + iOffsetSrc);
				unsigned int *pDest = (unsigned int*)((char*)pVis->m_pBuffer + iOffsetDest);
				for ( int j=0; j<w; j++ )
				{
					unsigned int pixel = *pSrc;
					// If alpha value non-zero
					if (pixel & 0xFF000000)
					{
						*pDest = pixel;
					}
					pSrc++;
					pDest++;
				}
			}
			djgUnlock( pVis );
			return;
		}
	}
	if (pVis->bpp==16)
	{
		if (pImage->BPP()==32)
		{
			djgLock( pVis );
			for ( int i=0; i<h; i++ )
			{
				int iOffsetSrc = (yS+i)*pImage->Pitch() + xS*4;
				int iOffsetDest = (yD+i)*pVis->stride + xD*2;
				unsigned int   *pSrc = (unsigned int*)((char*)pImage->Data() + iOffsetSrc);
				unsigned short *pDest = (unsigned short*)((char*)pVis->m_pBuffer + iOffsetDest);
				for ( int j=0; j<w; j++ )
				{
					unsigned int pixel = *pSrc;
					// If alpha value non-zero
					if (pixel & 0xFF000000)
					{
						*pDest = PIXEL32TO16(pixel);
					}
					pSrc++;
					pDest++;
				}
			}
			djgUnlock( pVis );
			return;
		}
	}
}

void djgDrawVisual( djVisual *pDest, djVisual *pSrc, int xD, int yD, int xS, int yS, int w, int h )
{
	if (pDest->m_bPrimary) TranslatePoint( xD, yD );
	RECT rcDest;
	RECT rcSrc;
	SetRect( &rcDest, xD, yD, xD+w, yD+h );
	SetRect( &rcSrc,  xS, yS, xS+w, yS+h );
	HRESULT hr = pDest->vis->Blt( &rcDest, pSrc->vis, &rcSrc, DDBLT_WAIT, NULL );
	if (FAILED(hr))
	{
		OutputDebugString("djgDrawVisual failed\n" );
	}
}


/*==========================================================================*/
//
// Private functions; helpers for DirectDraw platform only
//
/*==========================================================================*/

DWORD dwDJGWinThreadID=0;

bool bWindowCreated = false;

struct SDJGWinInfo
{
	int iWidth;
	int iHeight;
	bool bFullScreen;
};

SDJGWinInfo g_DJGWinInfo;

DWORD FAR PASCAL DJGWinThread(LPVOID pParams)
{
	WNDCLASSEX wcex;
	RECT rc;

	g_DJGWinInfo = *((SDJGWinInfo*)pParams);
	
	// Register the window class
	wcex.cbSize = sizeof(WNDCLASSEX); 
	
	wcex.style			= 0/*CS_HREDRAW | CS_VREDRAW*/;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= g_hInstance;
	wcex.hIcon			= /*LoadIcon(hInstance, (LPCTSTR)IDI_DELME)*/ NULL;
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= /*(LPCSTR)IDC_DELME*/NULL;
	wcex.lpszClassName	= g_szClassName;
	wcex.hIconSm		= NULL/*LoadIcon(wcex.hInstance, (LPCTSTR)IDI_SMALL)*/;
	
	if (0 == RegisterClassEx(&wcex))
		return -1;

	DWORD dwStyle = WS_OVERLAPPED|WS_CAPTION|WS_THICKFRAME;
	
	rc.left = 0;
	rc.top = 0;
	rc.right = g_DJGWinInfo.iWidth;
	rc.bottom = g_DJGWinInfo.iHeight;
	AdjustWindowRect( &rc, dwStyle, FALSE );
	
	// Create a window
	g_hWnd = CreateWindow(g_szClassName, "DJG Window", dwStyle,
		CW_USEDEFAULT, CW_USEDEFAULT,
		rc.right-rc.left, rc.bottom-rc.top,
		NULL, NULL, g_hInstance, NULL);
	
	if (!g_hWnd)
		return -2;
	
	// Show the window
	ShowWindow( g_hWnd, SW_SHOWNORMAL );
	UpdateWindow( g_hWnd );

	bWindowCreated = true;

	// Main message loop:
	MSG msg;
	while (GetMessage(&msg, NULL, 0, 0)) 
	{
	//	if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg)) 
	//	{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
	//	}
	}

	return msg.wParam;


	return 0;
}

int create_window( int iWidth, int iHeight, bool bFullScreen )
{
	
	// FIXME: Spawn a thread to handle the window, its messages etc. We
	// need to do this because a DJG application will occupy the main thread
	// the entire time it is running, since this is how it works in the Linux
	// version.

	SDJGWinInfo WinInfo;
	WinInfo.iWidth = iWidth;
	WinInfo.iHeight = iHeight;
	WinInfo.bFullScreen = bFullScreen;

	bWindowCreated = false;
	CreateThread( NULL, 0, DJGWinThread, (LPVOID)&WinInfo, 0, &dwDJGWinThreadID );
	while (!bWindowCreated)
	{
		// FIXME: USE EVENTS in future
		// FIXME: What if error?
		Sleep(5);
	}
	
	
	
	return 0;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;
	PAINTSTRUCT ps;
	HDC hdc;

	if (InputWndProc(hWnd, message, wParam, lParam))
	{
		return 0;
	}
	// In full-screen mode, we prevent certain things from happening, eg we
	// prevent the system menu from popping up
	if (g_DJGWinInfo.bFullScreen)
	{
		switch (message) 
		{
		case WM_SYSKEYDOWN:
		case WM_SYSKEYUP:
			return 0;
		case WM_SYSCOMMAND:
			return 0;
		}
	}
	
	switch (message) 
	{
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		EndPaint(hWnd, &ps);
		break;
	case WM_DESTROY:
		// FIXME: The main thread must also die if this thread closes the window,
		// not just vice versa
		PostQuitMessage(0);
		break;
	case WM_COMMAND:
		wmId    = LOWORD(wParam); 
		wmEvent = HIWORD(wParam); 
		break;
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}

