/*--------------------------------------------------------------------------*/
/* David Joffe '95/07/20 test key hook */
/*--------------------------------------------------------------------------*/

#include <stdlib.h>

#include "../djinput.h"
#include "../djgraph.h"
#include "../djlog.h"

#define DIRECTINPUT_VERSION 0x700
#include <dinput.h>

int g_iKeys[DJKEY_MAX] = { 0 };
int g_iKeysLast[DJKEY_MAX] = { 0 };
LPDIRECTINPUT       g_pDI         = NULL; // DirectInput object
LPDIRECTINPUTDEVICE g_pDIKeyboard = NULL; // DI Keyboard device
LPDIRECTINPUTDEVICE g_pDIMouse    = NULL; // DI Mouse device
DIMOUSESTATE g_MouseState;
//HANDLE g_hMouseEvent=NULL;
char g_acKeys[256]={0}; // DI key states

// This structure maps DirectInput key codes to DJ key codes
SdjKeyMapping key_pairs[] =
{
	{ DJKEY_F1,        DIK_F1 },
	{ DJKEY_F4,        DIK_F4 },
	{ DJKEY_F5,        DIK_F5 },
	{ DJKEY_GREYPLUS,  DIK_ADD },
	{ DJKEY_GREYMINUS, DIK_SUBTRACT },
	{ DJKEY_SPACE,     DIK_SPACE },
	{ DJKEY_ENTER,     DIK_RETURN },
	{ DJKEY_ESC,       DIK_ESCAPE },
	{ DJKEY_LEFT,      DIK_LEFT },
	{ DJKEY_RIGHT,     DIK_RIGHT },
	{ DJKEY_UP,        DIK_UP },
	{ DJKEY_PGUP,      DIK_PRIOR }, // FIXME: Is this the right way round?
	{ DJKEY_PGDN,      DIK_NEXT },
	{ DJKEY_DOWN,      DIK_DOWN },
	{ DJKEY_HOME,      DIK_HOME },
	{ DJKEY_END,       DIK_END },
	{ DJKEY_ALT,       DIK_RMENU },
	{ DJKEY_ALT,       DIK_LMENU },
	{ DJKEY_CTRL,      DIK_RCONTROL },
	{ DJKEY_CTRL,      DIK_LCONTROL },
	{ DJKEY_A,         DIK_A },
	{ DJKEY_A,         DIK_A },
	{ DJKEY_B,         DIK_B },
	{ DJKEY_B,         DIK_B },
	{ DJKEY_C,         DIK_C },
	{ DJKEY_C,         DIK_C },
	{ DJKEY_D,         DIK_D },
	{ DJKEY_D,         DIK_D },
	{ DJKEY_E,         DIK_E },
	{ DJKEY_E,         DIK_E },
	{ DJKEY_F,         DIK_F },
	{ DJKEY_F,         DIK_F },
	{ DJKEY_G,         DIK_G },
	{ DJKEY_G,         DIK_G },
	{ DJKEY_H,         DIK_H },
	{ DJKEY_H,         DIK_H },
	{ DJKEY_I,         DIK_I },
	{ DJKEY_I,         DIK_I },
	{ DJKEY_J,         DIK_J },
	{ DJKEY_J,         DIK_J },
	{ DJKEY_K,         DIK_K },
	{ DJKEY_K,         DIK_K },
	{ DJKEY_L,         DIK_L },
	{ DJKEY_L,         DIK_L },
	{ DJKEY_M,         DIK_M },
	{ DJKEY_M,         DIK_M },
	{ DJKEY_N,         DIK_N },
	{ DJKEY_N,         DIK_N },
	{ DJKEY_O,         DIK_O },
	{ DJKEY_O,         DIK_O },
	{ DJKEY_P,         DIK_P },
	{ DJKEY_P,         DIK_P },
	{ DJKEY_Q,         DIK_Q },
	{ DJKEY_Q,         DIK_Q },
	{ DJKEY_R,         DIK_R },
	{ DJKEY_R,         DIK_R },
	{ DJKEY_S,         DIK_S },
	{ DJKEY_S,         DIK_S },
	{ DJKEY_T,         DIK_T },
	{ DJKEY_T,         DIK_T },
	{ DJKEY_U,         DIK_U },
	{ DJKEY_U,         DIK_U },
	{ DJKEY_V,         DIK_V },
	{ DJKEY_V,         DIK_V },
	{ DJKEY_W,         DIK_W },
	{ DJKEY_W,         DIK_W },
	{ DJKEY_X,         DIK_X },
	{ DJKEY_X,         DIK_X },
	{ DJKEY_Y,         DIK_Y },
	{ DJKEY_Y,         DIK_Y },
	{ DJKEY_Z,         DIK_Z },
	{ DJKEY_Z,         DIK_Z },
	{ DJKEY_0,         DIK_0 },
	{ DJKEY_1,         DIK_1 },
	{ DJKEY_2,         DIK_2 },
	{ DJKEY_3,         DIK_3 },
	{ DJKEY_4,         DIK_4 },
	{ DJKEY_5,         DIK_5 },
	{ DJKEY_6,         DIK_6 },
	{ DJKEY_7,         DIK_7 },
	{ DJKEY_8,         DIK_8 },
	{ DJKEY_9,         DIK_9 },
	{ -1, 0 }
};
/*--------------------------------------------------------------------------*/
djVisual *g_pVisInput = NULL;
int           g_iFlags;
int           mouse_x;
int           mouse_y;
int           mouse_b;
/*--------------------------------------------------------------------------*/
typedef struct MYDATA { 
	LONG  lX;                   // X-axis goes here. 
	LONG  lY;                   // Y-axis goes here. 
	BYTE  bButtonA;             // One button goes here. 
	BYTE  bButtonB;             // Another button goes here. 
	BYTE  bPadding[2];          // Must be DWORD multiple in size. 
} MYDATA; 

void djiPoll()
{
	// Remember the key state from last time round
	memcpy( g_iKeysLast, g_iKeys, sizeof(g_iKeys) );
	if (g_pDIKeyboard)
	{
		
		HRESULT hr = g_pDIKeyboard->GetDeviceState(sizeof(g_acKeys), (LPVOID)g_acKeys);
		if FAILED(hr)
		{
			djMSG("Keyboard failed\n");
			if (hr == DIERR_INPUTLOST)
			{
				djMSG("Keyboard input lost");
				g_pDIKeyboard->Acquire();
			}
		}
		
		// Map DI keys to DJ keys
		memset( g_iKeys, 0, sizeof(g_iKeys) );
		for ( int i=0; key_pairs[i].m_iScanCode!=-1; i++ )
		{
			if (g_acKeys[key_pairs[i].m_iPlatformCode] & 0x80)
				g_iKeys[key_pairs[i].m_iScanCode] = 1;
		}
	}
	if (g_pDIMouse && (g_iFlags & INPUT_MOUSE))
	{
		// FIXME: THis is a mess. -593million?
/*		HRESULT hr = g_pDIMouse->GetDeviceState( sizeof(g_MouseState), &g_MouseState );
		if (FAILED(hr))
		{
			if (hr == DIERR_INPUTLOST)
			{
				djMSG("Mouse input lost");
				g_pDIMouse->Acquire();
			}
			return;
		}
		mouse_x = g_MouseState.lX;
		mouse_y = g_MouseState.lY;
		mouse_b = 0;
		if (g_MouseState.rgbButtons[0]) mouse_b |= 1;
		if (g_MouseState.rgbButtons[1]) mouse_b |= 2;
		if (g_MouseState.rgbButtons[2]) mouse_b |= 4;
		if (g_MouseState.rgbButtons[3]) mouse_b |= 8;*/

		/*		MYDATA Foo;
		HRESULT hr = g_pDIMouse->GetDeviceState( sizeof(Foo), &Foo );
		if (FAILED(hr))
		{
			djMSG("DFJ\n");
			return;
		}
		mouse_x = Foo.lX;
		mouse_y = Foo.lY;
		mouse_b = 0;
		if (Foo.bButtonA) mouse_b |= 1;
		if (Foo.bButtonB) mouse_b |= 2;*/

		//if (g_MouseState.rgbButtons[2]) mouse_b |= 4;
		//if (g_MouseState.rgbButtons[3]) mouse_b |= 8;
	}
}
/*--------------------------------------------------------------------------*/
// Brain damage thanks to fucked up MS API's
bool InputWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	// Handle windows mouse messages
	switch (message)
	{
	case WM_LBUTTONDOWN: mouse_b |= 1;  break;
	case WM_LBUTTONUP:   mouse_b &= ~1; break;
	case WM_MBUTTONDOWN: mouse_b |= 4;  break;
	case WM_MBUTTONUP:   mouse_b &= ~4; break;
	case WM_RBUTTONDOWN: mouse_b |= 2;  break;
	case WM_RBUTTONUP:   mouse_b &= ~2; break;
	case WM_MOUSEMOVE:
		{
			// ripped from clanlib
			int button_states = wParam;
			int x = LOWORD(lParam);
			int y = HIWORD(lParam);
			mouse_x = x;
			mouse_y = y;

		}
		return true;
	}
	return false;
}

bool djiInit( djVisual *pVis, int iFlags )
{
	g_iFlags = iFlags;
	
	g_pVisInput = pVis;
	
	// create DirectInput object
	HRESULT hr = DirectInputCreate(g_hInstance, DIRECTINPUT_VERSION, &g_pDI, NULL);
	if (FAILED(hr))
	{
		djMSG("SCREWUP\n");
		return false;
	}
	
	// Set up keyboard input
	hr = g_pDI->CreateDevice(GUID_SysKeyboard, &g_pDIKeyboard, NULL);
	if (FAILED(hr))
	{
		djMSG( "Keybd scewup\n" );
		return false;
	}
	hr = g_pDIKeyboard->SetDataFormat(&c_dfDIKeyboard);
	if (FAILED(hr))
	{
		djMSG( "KB SETdataformat screwup\n" );
		return false;
	}
	hr = g_pDIKeyboard->Acquire();
	if (FAILED(hr))
	{
		djMSG( "LKfsdjflskdfj\n" );
		return false;
	}

	// Initialize mouse variables
	mouse_b = 0;  // button
	mouse_x = -1; // x
	mouse_y = -1; // y
	
	if (g_iFlags & INPUT_MOUSE)
	{
		// Set up mouse input
		hr = g_pDI->CreateDevice(GUID_SysMouse, &g_pDIMouse, NULL);
		if (FAILED(hr))
		{
			djMSG( "Mouse screwup\n" );
			return false;
		}
		hr = g_pDIMouse->SetDataFormat(&c_dfDIMouse);
		if (FAILED(hr))
		{
			djMSG( "Mouse SetDataFormat messup\n" );
			return false;
			}/*
			 hr = g_pDIMouse->SetCooperativeLevel( HWND NEEDED HERE, DISCL_NONEXCLUSIVE|DISCL_FOREGROUND );
			 if (FAILED(hr))
			 {
			 djMSG( "Mouse SetCooperativeLevel messup\n" );
			 return false;
			 }
			 g_hMouseEvent = CreateEvent(0, 0, 0, 0);
			 if (g_hMouseEvent==NULL)
			 return false;
			 hr = g_pDIMouse->SetEventNotification( g_hMouseEvent );
			 if (FAILED(hr))
			 {
			 djMSG( "Mouse SetEventNotification messup\n" );
			 return false;
			 }
			 DIPROPDWORD dipdw;
			 dipdw.diph.dwSize = sizeof(dipdw);
			 dipdw.diph.dwHeaderSize = sizeof(dipdw.diph);
			 dipdw.diph.dwObj = 0;
			 dipdw.diph.DIPH_DEVICE;
			 dipdw.dwData = 16;
			 hr = g_pDIMouse->SetProperty( DIPROP_BUFFERSIZE, &dipdw.diph );
			 if (FAILED(hr))
			 {
			 djMSG("holy shit, enough already with the f-ing mouse setup functions ...\n");
			 return false;
	}*/

		// Set absolute axis mode
		/*DIPROPDWORD dipdw;
		dipdw.diph.dwSize = sizeof(dipdw);
		dipdw.diph.dwHeaderSize = sizeof(dipdw.diph);
		dipdw.diph.dwObj = 0;
		dipdw.diph.dwHow = DIPH_DEVICE;
		dipdw.dwData = DIPROPAXISMODE_ABS;
		hr = g_pDIMouse->SetProperty( DIPROP_AXISMODE, &dipdw.diph );
		if (FAILED(hr))
		{
		djMSG("holy shit, enough already with the f-ing mouse setup functions ...\n");
		return false;
		}
		*/
		
		
		// Then, it can use the following data format. 
		
		DIOBJECTDATAFORMAT rgodf[ ] = { 
			{ &GUID_XAxis, FIELD_OFFSET(MYDATA, lX),
				DIDFT_AXIS | DIDFT_ANYINSTANCE, 0, }, 
			{ &GUID_YAxis, FIELD_OFFSET(MYDATA, lY), 
			DIDFT_AXIS | DIDFT_ANYINSTANCE, 0, }, 
			{ &GUID_Button, FIELD_OFFSET(MYDATA, bButtonA),
			DIDFT_BUTTON | DIDFT_ANYINSTANCE, 0, }, 
			{ &GUID_Button, FIELD_OFFSET(MYDATA, bButtonB), 
			DIDFT_BUTTON | DIDFT_ANYINSTANCE, 0, }, 
		}; 
		
		DIDATAFORMAT df = { 
			sizeof(DIDATAFORMAT),       // this structure 
				sizeof(DIOBJECTDATAFORMAT), // size of object data format 
				DIDF_ABSAXIS,               // absolute axis coordinates 
				sizeof(MYDATA),             // device data size 
				(sizeof(rgodf) / sizeof(rgodf[0])), // number of objects 
				rgodf,                      // and here they are 
		}; 
		hr = g_pDIMouse->SetDataFormat( &df );
		if (FAILED(hr))
		{
			djMSG("Failed to setdataformat on mouse\n" );
			return false;
		}

		hr = g_pDIMouse->Acquire();
		if (FAILED(hr))
		{
			djMSG("MOUSE FAILED TO ACQUIRE\n");
			return false;
		}
		MYDATA Foo;
		hr = g_pDIMouse->GetDeviceState( sizeof(Foo), &Foo );
		if (FAILED(hr))
		{
			djMSG("DFJ\n");
			return false;
		}
		mouse_x = Foo.lX;
		mouse_y = Foo.lY;
		mouse_b = 0;
		if (Foo.bButtonA) mouse_b |= 1;
		if (Foo.bButtonB) mouse_b |= 2;
		//if (g_MouseState.rgbButtons[2]) mouse_b |= 4;
		//if (g_MouseState.rgbButtons[3]) mouse_b |= 8;
	}
	
	return true;
}
/*--------------------------------------------------------------------------*/
void djiDone()
{
	if (g_pDIMouse)
	{
		g_pDIMouse->Unacquire();
		g_pDIMouse->Release();
		g_pDIMouse = NULL;
	}

	if (g_pDIKeyboard)
	{
		g_pDIKeyboard->Unacquire();
		g_pDIKeyboard->Release();
		g_pDIKeyboard = NULL;
	}

	if (g_pDI)
	{
		g_pDI->Release();
		g_pDI = NULL;
	}
}

void djiWaitForKeyUp(char cKey)
{
	do
	{
		djiPoll();
	} while (g_iKeys[cKey]);
}

bool djiAnyKeyDown()
{
	int i,r=0;
	for (i = 0;i<128;i++)
	{
		r = r | g_iKeys[i];
	}
	return(r!=0);
}

bool djiKeyDown(int iScanCode)
{
	return g_iKeys[iScanCode]!=0;
}

bool djiKeyPressed(int iScanCode)
{
	return (g_iKeys[iScanCode]!=0 && g_iKeysLast[iScanCode]==0);
}

